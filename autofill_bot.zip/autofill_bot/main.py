import os
import tempfile
import telebot
from docx import Document
from docx.oxml.ns import qn
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from dotenv import load_dotenv
import re
import uuid

load_dotenv()
BOT_TOKEN = os.getenv("BOT_TOKEN")

if not BOT_TOKEN:
    raise ValueError("Токен бота не найден! Убедитесь, что .env содержит BOT_TOKEN")

bot = telebot.TeleBot(BOT_TOKEN)
user_data = {}

def escape_markdown(text):
    return re.sub(r'([_\*\[\]()~`>#+\-=|{}.!\\])', r'\\\1', text)

@bot.message_handler(commands=['start'])
def handle_start(message):
    bot.send_message(
        message.chat.id,
        "\U0001F44B Привет! Отправьте .docx документ для замены текста с сохранением форматирования."
    )

@bot.message_handler(content_types=['document'])
def handle_document(message):
    chat_id = message.chat.id
    user_id = message.from_user.id

    if not message.document.file_name.endswith('.docx'):
        bot.send_message(chat_id, "\u274C Пожалуйста, отправьте файл в формате .docx")
        return

    try:
        unique_id = str(uuid.uuid4())[:8]
        file_info = bot.get_file(message.document.file_id)
        downloaded_file = bot.download_file(file_info.file_path)

        user_dir = os.path.join(tempfile.gettempdir(), f"bot_{user_id}")
        os.makedirs(user_dir, exist_ok=True)

        filename = f"{unique_id}_{message.document.file_name}"
        file_path = os.path.join(user_dir, filename)

        with open(file_path, 'wb') as f:
            f.write(downloaded_file)

        if chat_id not in user_data:
            user_data[chat_id] = {}

        user_data[chat_id][filename] = {
            'original_doc': file_path,
            'original_name': message.document.file_name,
            'replacements': {},
            'font_name': None,
            'font_size': None
        }

        msg = bot.send_message(
            chat_id,
            f"\U0001F4C4 Файл '{escape_markdown(message.document.file_name)}' получен.\n"
            "Введите замены в формате:\n"
            "`оригинальный текст : новый текст`\n"
            "Пример: `24 июня 2025 г. : 17 июля 2025 г.`\n"
            "Когда закончите, введите /done",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(msg, lambda m: process_replacements(m, filename))
    except Exception as e:
        bot.send_message(chat_id, f"\u274C Ошибка при загрузке файла: {str(e)}")

def process_replacements(message, filename):
    chat_id = message.chat.id

    if message.text == '/done':
        if not user_data.get(chat_id, {}).get(filename, {}).get('replacements'):
            bot.send_message(chat_id, "\u26A0\uFE0F Вы не ввели ни одной замены. Попробуйте снова.")
            return

        msg = bot.send_message(
            chat_id,
            f"\u270F\uFE0F Для файла '{escape_markdown(filename)}': Введите название шрифта (например: Times New Roman):",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(msg, lambda m: ask_font_size(m, filename))
        return

    try:
        old_text, new_text = [part.strip() for part in message.text.split(':', 1)]
        if not old_text or not new_text:
            raise ValueError
    except Exception:
        msg = bot.send_message(
            chat_id,
            "\u274C Неправильный формат!\nИспользуйте:\n"
            "`старый текст : новый текст`\n"
            "Пример: `Акт : Документ`\n"
            "Или введите /done",
            parse_mode="Markdown"
        )
        bot.register_next_step_handler(msg, lambda m: process_replacements(m, filename))
        return

    user_data[chat_id][filename]['replacements'][old_text] = new_text

    msg = bot.send_message(
        chat_id,
        f"\u2705 Замена сохранена для файла '{escape_markdown(filename)}':\n"
        f"`{escape_markdown(old_text)}` → `{escape_markdown(new_text)}`\n"
        "Введите следующую или /done",
        parse_mode="Markdown"
    )
    bot.register_next_step_handler(msg, lambda m: process_replacements(m, filename))

def ask_font_size(message, filename):
    chat_id = message.chat.id
    font_name = message.text.strip()

    if chat_id not in user_data or filename not in user_data[chat_id]:
        bot.send_message(chat_id, "\u26A0\uFE0F Сессия устарела. Пожалуйста, начните заново.")
        return

    user_data[chat_id][filename]['font_name'] = font_name

    msg = bot.send_message(
        chat_id,
        f"\U0001F4CF Укажите размер шрифта (например: 12):"
    )
    bot.register_next_step_handler(msg, lambda m: finalize_document(m, filename))

def finalize_document(message, filename):
    chat_id = message.chat.id

    try:
        font_size = int(message.text.strip())
        if font_size <= 0:
            raise ValueError
    except Exception:
        msg = bot.send_message(
            chat_id,
            "\u274C Некорректный размер! Введите целое положительное число (например: 12)."
        )
        bot.register_next_step_handler(msg, lambda m: finalize_document(m, filename))
        return

    data = user_data[chat_id][filename]
    data['font_size'] = font_size

    try:
        modified_doc_path = modify_document(
            data['original_doc'],
            data['replacements'],
            data['font_name'],
            data['font_size']
        )

        with open(modified_doc_path, 'rb') as doc_file:
            bot.send_document(
                chat_id,
                doc_file,
                visible_file_name=data['original_name']
            )

        os.remove(data['original_doc'])
        os.remove(modified_doc_path)

    except Exception as e:
        bot.send_message(chat_id, f"\u2757 Ошибка при обработке файла: {str(e)}")
    finally:
        user_data[chat_id].pop(filename, None)
        if not user_data[chat_id]:
            user_data.pop(chat_id)

def modify_document(input_path, replacements, font_name, font_size):
    doc = Document(input_path)

    # Сначала делаем замены в параграфах
    for paragraph in doc.paragraphs:
        full_text = paragraph.text
        for old, new in replacements.items():
            full_text = full_text.replace(old, new)
        paragraph.text = full_text

    # Ищем блоки с ФИО и должностями, чтобы собрать их для таблицы
    fio_blocks = []
    remove_paragraphs = []
    for i, paragraph in enumerate(doc.paragraphs):
        text = paragraph.text.strip()
        # Примерный паттерн для строки с ФИО в конце
        # Можно доработать, если знаешь более точный формат
        if re.search(r'[А-ЯЁ][а-яё]+\s[А-ЯЁ]\.[А-ЯЁ]\.$', text):
            # Разделяем на "должность" и "ФИО"
            parts = re.split(r'\s{2,}', text)
            if len(parts) >= 2:
                fio_blocks.append(parts)
                remove_paragraphs.append(paragraph)

    # Удаляем исходные параграфы с ФИО, чтобы не дублировать
    for p in remove_paragraphs:
        p._element.getparent().remove(p._element)

    # Создаём таблицу с двумя колонками
    if fio_blocks:
        table = doc.add_table(rows=len(fio_blocks), cols=2)
        table.autofit = False
        # Фиксируем ширину колонок (примерно, можно подкорректировать)
        table.columns[0].width = Cm(11)
        table.columns[1].width = Cm(6)

        for row_idx, parts in enumerate(fio_blocks):
            cell_0 = table.cell(row_idx, 0)
            cell_1 = table.cell(row_idx, 1)
            cell_0.text = parts[0].strip()
            cell_1.text = parts[1].strip()
            for paragraph in [cell_0.paragraphs[0], cell_1.paragraphs[0]]:
                paragraph.alignment = WD_ALIGN_PARAGRAPH.LEFT

    # Применяем шрифт и размер
    set_document_font(doc, font_name, font_size)

    output_path = input_path.replace('.docx', '_modified.docx')
    doc.save(output_path)
    return output_path

def set_document_font(doc, font_name, font_size):
    for paragraph in doc.paragraphs:
        for run in paragraph.runs:
            run.font.name = font_name
            run.font.size = Pt(font_size)
            run._element.rPr.rFonts.set(qn('w:eastAsia'), font_name)

    for table in doc.tables:
        for row in table.rows:
            for cell in row.cells:
                for paragraph in cell.paragraphs:
                    for run in paragraph.runs:
                        run.font.name = font_name
                        run.font.size = Pt(font_size)
                        run._element.rPr.rFonts.set(qn('w:eastAsia'), font_name)

if __name__ == '__main__':
    print("Бот запущен...")
    bot.polling(none_stop=True, timeout=60, long_polling_timeout=60)
